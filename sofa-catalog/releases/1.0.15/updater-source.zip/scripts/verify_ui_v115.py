from pathlib import Path
import json
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1]
A=R/'android/assets'
errors=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path=r'C:\Program Files\Google\Chrome\Application\chrome.exe',headless=True)
 c=b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
 p=c.new_page();p.on('pageerror',lambda e:errors.append(str(e)))
 p.goto((A/'index.html').as_uri());p.wait_for_selector('.card')
 assert p.locator('.card').count()==377
 assert p.locator('.card').evaluate_all('(es)=>es.every(e=>e.innerText.trim()==="")')
 assert len(p.locator('#grid').evaluate('(e)=>getComputedStyle(e).gridTemplateColumns.split(" ")'))==2
 assert p.locator('.card').first.bounding_box()['y']<210
 for label in p.locator('#tabs button').all_text_contents():
  p.get_by_role('button',name=label,exact=True).click()
  assert p.locator('.card').count()>0,label
  assert p.locator('.card').evaluate_all('(es)=>es.every(e=>e.innerText.trim()==="")')
 p.get_by_role('button',name='Natuzzi Italia',exact=True).click()
 assert p.locator('.card').count()==15
 p.screenshot(path=str(R/'phone-preview-v1.0.15-natuzzi.png'))
 p.locator('.card').first.click()
 assert 'Amama' in p.locator('#body').inner_text()
 p.wait_for_function("document.querySelector('#hero').complete && document.querySelector('#hero').naturalWidth>0")
 p.locator('#star').click();p.locator('#back').click();p.reload()
 p.locator('#favorites').click();assert p.locator('.card').count()==1
 p.locator('.card').first.click();p.get_by_role('button',name='放大看图',exact=True).click()
 assert p.evaluate('window.appBack()');assert p.evaluate('window.appBack()')
 p.locator('#favorites').click()
 p.locator('#search').fill('___no_such_model___');assert p.locator('#empty').is_visible()
 p.locator('#search').fill('Fly');assert p.locator('.card').count()>0
 p.locator('#search').fill('')
 p.locator('#update-open').click();assert p.locator('#updates').is_visible()
 assert p.locator('#update-check').is_disabled()
 p.evaluate("window.onCatalogUpdate({phase:'downloading',contentVersionName:'1.0.16',appVersion:'1.0.15',message:'下载中'})")
 assert p.locator('#update-repair').is_disabled()
 p.evaluate("window.onCatalogUpdate({phase:'error',message:'网络暂时不可用，仍可使用当前版本'})")
 assert p.locator('#update-check').is_enabled()
 assert '网络' in p.locator('#update-message').inner_text()
 assert p.evaluate('window.appBack()')
 for w in [360,390,768,1280]:
  p.set_viewport_size({'width':w,'height':844})
  assert p.evaluate('document.documentElement.scrollWidth<=innerWidth'),w
 p.set_viewport_size({'width':390,'height':844})
 p.get_by_role('button',name='全部',exact=True).click()
 p.screenshot(path=str(R/'phone-preview-v1.0.15.png'))
 c.set_offline(True);p.reload();p.wait_for_selector('.card')
 assert p.locator('.card').count()==377
 p.locator('.card').first.click()
 p.wait_for_function("document.querySelector('#hero').complete && document.querySelector('#hero').naturalWidth>0")
 assert not errors,errors
 c.close();b.close()
result={'version':'1.0.15','records':377,'image_only_cards':True,'mobile_columns':2,'tested_widths':[360,390,768,1280],'tests':['brand filters','detail','favorite persistence','zoom/back','search/empty','update panel/status/error','no overflow','offline originals'],'page_errors':errors,'native_update_runtime_tested':False}
(R/'verification-v1.0.15-ui.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
