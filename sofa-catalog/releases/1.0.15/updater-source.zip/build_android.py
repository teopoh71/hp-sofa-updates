from pathlib import Path
import os,sys,json,subprocess,zipfile,shutil,secrets,hashlib,re
ROOT=Path(__file__).resolve().parent;A=ROOT/"android";B=A/"build";B.mkdir(exist_ok=True)
SDK=Path.home()/"AppData/Local/Android/Sdk";BT=SDK/"build-tools/35.0.0";JDK=Path(r"C:\Program Files\Eclipse Adoptium\jdk-17.0.19.10-hotspot\bin")
def run(args,env=None):
 p=subprocess.run([str(a) for a in args],capture_output=True,text=True,encoding="utf-8",errors="replace",env=env)
 if p.returncode:
  print(p.stdout[-2000:]);print(p.stderr[-2000:]);raise RuntimeError("Build step failed: "+str(args[0]))
 return p.stdout
private=ROOT/".private";private.mkdir(exist_ok=True)
assets=A/"assets"
run([BT/"aapt2.exe","compile","--dir",A/"res","-o",B/"resources.zip"])
run([BT/"aapt2.exe","link","-o",B/"unsigned.apk","-I",SDK/"platforms/android-35/android.jar","--manifest",A/"AndroidManifest.xml","-A",assets,B/"resources.zip"])
classes=B/"classes"
if classes.exists():shutil.rmtree(classes)
classes.mkdir()
run([JDK/"javac.exe","-encoding","UTF-8","-source","8","-target","8","-classpath",SDK/"platforms/android-35/android.jar","-d",classes,*sorted(A.glob("*.java"))])
classes_files=list(classes.rglob("*.class"))
dex=B/"dex";dex.mkdir(exist_ok=True)
run([JDK/"java.exe","-cp",BT/"lib/d8.jar","com.android.tools.r8.D8","--lib",SDK/"platforms/android-35/android.jar","--min-api","26","--output",dex,*classes_files])
with zipfile.ZipFile(B/"unsigned.apk","a",zipfile.ZIP_DEFLATED) as z:z.write(dex/"classes.dex","classes.dex")
run([BT/"zipalign.exe","-f","4",B/"unsigned.apk",B/"aligned.apk"])
private=ROOT/".private";pwfile=private/"sign-password.txt"
if not pwfile.exists():raise RuntimeError("Existing signing password file is required; refusing to create a replacement identity")
env=os.environ.copy();env["SOFA_SIGN_PASSWORD"]=pwfile.read_text().strip()
ks=private/"sofa-release.jks"
if not ks.exists():raise RuntimeError("Existing release keystore is required; refusing to change the APK signing identity")
manifest_text=(A/"AndroidManifest.xml").read_text(encoding="utf-8")
version=re.search(r'android:versionName="([^"]+)"',manifest_text).group(1)
out=ROOT/f"Sofa-Catalog-v{version}.apk"
run([JDK/"java.exe","-jar",BT/"lib/apksigner.jar","sign","--ks",ks,"--ks-key-alias","sofa","--ks-pass","env:SOFA_SIGN_PASSWORD","--key-pass","env:SOFA_SIGN_PASSWORD","--out",out,B/"aligned.apk"],env)
verification=run([JDK/"java.exe","-jar",BT/"lib/apksigner.jar","verify","--verbose",out])
badging=run([BT/"aapt.exe","dump","badging",out])
(ROOT/"apk-verification.txt").write_text(verification+"\n"+badging,encoding="utf-8")
print(json.dumps({"apk":out.name,"bytes":out.stat().st_size,"sha256":hashlib.sha256(out.read_bytes()).hexdigest(),"verified":True,"package":"com.edwin.sofacatalog","version":version}))
