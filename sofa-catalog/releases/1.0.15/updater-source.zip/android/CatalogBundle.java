package com.edwin.sofacatalog;

import java.io.*;
import java.net.URI;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.*;

/** Pure Java validator used both by the Android updater and host-side failure tests. */
public final class CatalogBundle {
    public static final long MAX_ZIP = 150L * 1024 * 1024;
    public static final long MAX_EXPANDED = 250L * 1024 * 1024;
    public static final long MAX_FILE = 30L * 1024 * 1024;
    public static final int MAX_FILES = 6000;
    public static final String BASE = "https://teopoh71.github.io/hp-sofa-updates/sofa-catalog/";

    public static final class Spec {
        public final String path, hash;
        public final long size;
        public Spec(String p, String h, long s) throws IOException {
            if (!validPath(p) || h == null || !h.matches("[a-fA-F0-9]{64}") || s < 0 || s > MAX_FILE)
                throw new IOException("更新文件清单无效");
            path=p; hash=h.toLowerCase(Locale.ROOT); size=s;
        }
    }
    public static boolean validPath(String p) {
        if ("_manifest.json".equalsIgnoreCase(p) || p == null || p.isEmpty() || p.length() > 240 || !p.matches("[A-Za-z0-9_./-]+") ||
            p.startsWith("/") || p.contains("//")) return false;
        for (String part : p.split("/")) if (part.isEmpty() || part.equals(".") || part.equals("..")) return false;
        String lower=p.toLowerCase(Locale.ROOT);
        return lower.matches(".*\\.(html|js|css|json|png|jpg|jpeg|webp|gif|svg|woff|woff2)$");
    }
    public static boolean trustedUrl(String u) {
        try {
            URI x=new URI(u);
            return "https".equals(x.getScheme()) && "teopoh71.github.io".equalsIgnoreCase(x.getHost()) &&
                x.getPort()==-1 && x.getUserInfo()==null && x.getRawQuery()==null && x.getFragment()==null &&
                x.getRawPath().startsWith("/hp-sofa-updates/sofa-catalog/") &&
                !x.getRawPath().contains("%") && !x.getRawPath().contains("\\") &&
                x.normalize().equals(x) && !x.getRawPath().contains("//");
        } catch (Exception e) { return false; }
    }
    public static String hash(File file) throws Exception {
        MessageDigest m=MessageDigest.getInstance("SHA-256");
        try(InputStream in=new BufferedInputStream(new FileInputStream(file))) {
            byte[] b=new byte[65536]; int n;
            while((n=in.read(b))!=-1) m.update(b,0,n);
        }
        return hex(m.digest());
    }
    private static String hex(byte[] data) {
        StringBuilder s=new StringBuilder();
        for(byte b:data)s.append(String.format(Locale.ROOT,"%02x",b&255));
        return s.toString();
    }
    public static void validateSet(Map<String,Spec> files,long expanded) throws IOException {
        if(files.size()<2 || files.size()>MAX_FILES || !files.containsKey("index.html") || !files.containsKey("data.js"))
            throw new IOException("更新缺少页面或目录");
        long total=0;
        Set<String> insensitive=new HashSet<>();
        for(Spec f:files.values()) {
            total+=f.size;
            if(!insensitive.add(f.path.toLowerCase(Locale.ROOT)))throw new IOException("更新路径重复");
        }
        if(total>MAX_EXPANDED || expanded!=total)throw new IOException("更新展开大小不匹配");
    }
    public static void extract(File zip, File destination, Map<String,Spec> files,long expanded) throws Exception {
        validateSet(files,expanded);
        if(!destination.isDirectory() && !destination.mkdirs())throw new IOException("无法准备更新目录");
        Set<String> seen=new HashSet<>();
        long total=0;
        try(ZipInputStream in=new ZipInputStream(new BufferedInputStream(new FileInputStream(zip)))) {
            ZipEntry entry; int entries=0;
            byte[] data=new byte[65536];
            while((entry=in.getNextEntry())!=null) {
                if(++entries>MAX_FILES*2)throw new IOException("更新压缩条目超限");
                String p=entry.getName();
                // Directory entries carry no content; validate their path too.
                if(entry.isDirectory()) {
                    String d=p.endsWith("/")?p.substring(0,p.length()-1):p;
                    if(!validPath(d+"/x.json"))throw new IOException("更新目录路径无效");
                    if(entry.getSize()>0 || in.read()!=-1)throw new IOException("更新目录包含无效载荷");
                    in.closeEntry(); continue;
                }
                Spec spec=files.get(p);
                if(spec==null || !validPath(p) || !seen.add(p))throw new IOException("更新含未授权或重复文件");
                File out=new File(destination,p);
                if(!out.getCanonicalPath().startsWith(destination.getCanonicalPath()+File.separator))
                    throw new IOException("更新路径越界");
                File parent=out.getParentFile();
                if(!parent.isDirectory()&&!parent.mkdirs())throw new IOException("无法创建更新目录");
                MessageDigest md=MessageDigest.getInstance("SHA-256");
                long size=0;
                try(OutputStream os=new BufferedOutputStream(new FileOutputStream(out))) {
                    int n;
                    while((n=in.read(data))!=-1) {
                        size+=n; total+=n;
                        if(size>spec.size || total>expanded)throw new IOException("更新文件超出大小限制");
                        md.update(data,0,n); os.write(data,0,n);
                    }
                }
                if(size!=spec.size || !hex(md.digest()).equals(spec.hash))throw new IOException("更新文件校验失败");
                in.closeEntry();
            }
        }
        if(seen.size()!=files.size() || total!=expanded)throw new IOException("更新文件不完整");
    }
    public static void verifyDirectory(File dir,Map<String,Spec> files,long expanded) throws Exception {
        validateSet(files,expanded);
        for(Spec f:files.values()) {
            File file=new File(dir,f.path);
            if(!file.isFile()||file.length()!=f.size||!hash(file).equals(f.hash))
                throw new IOException("已下载资料损坏");
        }
    }
    public static void deleteTree(File file) {
        if(file==null || !file.exists())return;
        if(file.isDirectory()) { File[] children=file.listFiles(); if(children!=null)for(File f:children)deleteTree(f); }
        file.delete();
    }
}