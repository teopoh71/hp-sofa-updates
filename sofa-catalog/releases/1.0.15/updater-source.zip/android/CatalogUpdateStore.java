package com.edwin.sofacatalog;

import android.content.Context;
import android.util.AtomicFile;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Downloads only the pinned public Sofa Catalog feed; never changes user favorites. */
public final class CatalogUpdateStore {
    public static final int APP_CODE=10015;
    public static final String APP_VERSION="1.0.15";
    public static final String FEED=CatalogBundle.BASE+"manifest.json";
    public static final String INSTALLER=CatalogBundle.BASE+"download.html";
    private static final int MANIFEST_LIMIT=2*1024*1024;
    private final Context context;
    private final File root;
    private final AtomicFile stateFile;
    private static final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final ConcurrentMap<String,Release> knownReleases=new ConcurrentHashMap<>();
    private volatile boolean closed=false;
    private volatile HttpURLConnection activeConnection;
    private final AtomicBoolean busy=new AtomicBoolean(false);
    private final Listener listener;
    private volatile Release active;
    private volatile String phase="ready",message="内置资料可离线使用";
    private volatile int progress=0;
    private volatile boolean pending=false, initialized=false;
    private String previousId="";
    public interface Listener { void changed(String json); void reload(); }
    private static final class Release {
        String id,name,url,hash;
        int code,minApp;
        long zipSize,total;
        JSONObject manifest;
        Map<String,CatalogBundle.Spec> files=new LinkedHashMap<>();
        File directory;
    }

    public CatalogUpdateStore(Context c,Listener l) {
        context=c.getApplicationContext(); listener=l;
        root=new File(context.getFilesDir(),"catalog-updates");
        root.mkdirs();
        stateFile=new AtomicFile(new File(root,"state.json"));
    }
    public String status() {
        JSONObject j=new JSONObject();
        Release a=active;
        try {
            j.put("phase",phase).put("message",message).put("busy",busy.get()).put("progress",progress)
             .put("appVersion",APP_VERSION).put("appVersionCode",APP_CODE)
             .put("contentVersionCode",a==null?APP_CODE:a.code)
             .put("contentVersionName",a==null?APP_VERSION:a.name)
             .put("source",a==null?"bundled":"downloaded").put("endpoint",FEED)
             .put("pendingVerification",pending);
        } catch(JSONException ignored) {}
        return j.toString();
    }
    private void publish(String p,String m,int n) {
        phase=p;message=m;progress=Math.max(0,Math.min(100,n));changed();
    }
    private void changed(){if(!closed)listener.changed(status());}
    private void reload(){if(!closed)listener.reload();}
    private void cancelled() throws IOException {if(closed)throw new IOException("更新已取消");}
    public String activeToken(){Release r=active;return r==null?"bundled":r.id;}
    public static final class Page {public final String html,token;Page(String h,String t){html=h;token=t;}}
    public Page page() throws IOException {String token=activeToken();return new Page(new String(readLimited(openToken(token,"index.html"),(int)CatalogBundle.MAX_FILE),StandardCharsets.UTF_8),token);}
    public void start() {
        if(!busy.compareAndSet(false,true))return;
        worker.execute(()->{
            try {
                cancelled();
                JSONObject saved=null;
                try { saved=new JSONObject(new String(stateFile.readFully(),StandardCharsets.UTF_8)); }
                catch(Exception ignored) {}
                if(saved!=null) {
                    String id=saved.optString("active","");
                    if(saved.optBoolean("pending",false)) {
                        id=saved.optString("previous","");
                        publish("rolled_back","上次更新未完成，已恢复可用资料",0);
                    }
                    if(!id.isEmpty()) {
                        try { active=readRelease(id); }
                        catch(Exception bad) {
                            try { active=readRelease(saved.optString("previous","")); }
                            catch(Exception ignored) { active=null; }
                            publish("rolled_back","资料校验未通过，已恢复可用版本",0);
                        }
                    }
                }
                pending=false; previousId="";
                persist();
                initialized=true;
                cleanup();
                reload();
                performCheck(false);
            } catch(Exception e) { publish("offline","联网更新暂不可用，当前资料仍可使用",0); }
            finally { busy.set(false);changed(); }
        });
    }
    public String check() {
        if(closed||!initialized)return status();
        if(!busy.compareAndSet(false,true))return status();
        publish("checking","正在检查在线更新",0);
        worker.execute(()->{
            try {performCheck(false);}
            catch(Exception e){publish("error",safeMessage(e),0);}
            finally{busy.set(false);changed();}
        });
        return status();
    }
    /** Rebuild web resources from the bundled copy then force download, keeping localStorage. */
    public String repair() {
        if(closed||!initialized || !busy.compareAndSet(false,true))return status();
        publish("repairing","正在恢复本地资料并重新下载",0);
        worker.execute(()->{
            try {
                active=null; pending=false;previousId="";
                persist(); reload();
                performCheck(true);
            } catch(Exception e) {publish("error","已恢复内置资料；"+safeMessage(e),0);}
            finally{busy.set(false);changed();}
        });
        return status();
    }
    public String restoreBundled() {
        if(closed||!initialized || !busy.compareAndSet(false,true))return status();
        worker.execute(()->{
            try{
                active=null;pending=false;previousId="";persist();
                publish("restored","已恢复内置资料，收藏保持不变",100);reload();
            }catch(Exception e){publish("error","恢复资料未完成，请重试",0);}
            finally{busy.set(false);changed();}
        });
        return status();
    }
    private String safeMessage(Exception e) {
        String m=e.getMessage();
        if(m!=null && (m.startsWith("更新")||m.startsWith("当前")||m.startsWith("请先")))return m;
        return "更新未完成，请检查网络后重试；当前资料仍可使用";
    }
    private void performCheck(boolean force) throws Exception {
        cancelled();
        publish("checking","正在检查在线更新",0);
        byte[] manifest=downloadBytes(FEED,MANIFEST_LIMIT);
        Release next=parse(new JSONObject(new String(manifest,StandardCharsets.UTF_8)));
        int current=active==null?APP_CODE:active.code;
        if(next.minApp>APP_CODE) {
            publish("app_required","请先从下载安装入口覆盖安装新版 APP",0);return;
        }
        if(next.code<APP_CODE || (!force && next.code<=current)) {
            publish("current","已是当前版本",100);return;
        }
        next.id="r"+next.code+"-"+UUID.randomUUID().toString().replace("-","");
        File staging=new File(root,"stage-"+UUID.randomUUID().toString());
        File zip=new File(root,"download-"+UUID.randomUUID().toString()+".zip");
        try {
            if(root.getUsableSpace()<next.zipSize+next.total+16L*1024*1024)throw new IOException("更新空间不足，请先释放手机存储空间");
            publish("downloading","正在下载界面、图片和目录",1);
            downloadBundle(next,zip);
            publish("verifying","正在校验完整更新包",85);
            if(!CatalogBundle.hash(zip).equals(next.hash))throw new IOException("更新包校验失败，已保留原版本");
            CatalogBundle.extract(zip,staging,next.files,next.total);
            write(new File(staging,"_manifest.json"),manifest);
            File committed=new File(root,next.id);
            if(!staging.renameTo(committed))throw new IOException("更新安装目录准备失败");
            next.directory=committed;
            cancelled();
            knownReleases.put(next.id,next);
            Release old=active;
            String oldPrevious=previousId;
            previousId=old==null?"":old.id;active=next;pending=true;
            try { persist(); }
            catch(Exception e){active=old;pending=false;previousId=oldPrevious;CatalogBundle.deleteTree(committed);throw e;}
            publish("installed","更新已校验，正在启用",100);
            reload();
        } finally {CatalogBundle.deleteTree(staging);CatalogBundle.deleteTree(zip);}
    }
    private Release parse(JSONObject j) throws Exception {
        if(j.optInt("schemaVersion")!=1 || !"com.edwin.sofacatalog".equals(j.optString("appId")))
            throw new IOException("更新清单不属于本应用");
        Release r=new Release();r.manifest=j;
        r.code=j.getInt("contentVersionCode");r.name=j.getString("contentVersionName");r.minApp=j.getInt("minAppVersionCode");
        if(r.code<1||r.name.length()>80||r.minApp<1)throw new IOException("更新版本信息无效");
        JSONObject bundle=j.getJSONObject("bundle");
        r.url=bundle.getString("url");r.hash=bundle.getString("sha256").toLowerCase(Locale.ROOT);
        r.zipSize=bundle.getLong("size");r.total=bundle.getLong("uncompressedSize");
        if(!CatalogBundle.trustedUrl(r.url)||!r.url.endsWith(".zip")||!r.hash.matches("[a-f0-9]{64}")||
           r.zipSize<=0||r.zipSize>CatalogBundle.MAX_ZIP||r.total<=0||r.total>CatalogBundle.MAX_EXPANDED)
            throw new IOException("更新包地址或大小无效");
        JSONArray files=j.getJSONArray("files");
        if(files.length()>CatalogBundle.MAX_FILES)throw new IOException("更新文件数量超限");
        for(int i=0;i<files.length();i++) {
            JSONObject f=files.getJSONObject(i);
            CatalogBundle.Spec s=new CatalogBundle.Spec(f.getString("path"),f.getString("sha256"),f.getLong("size"));
            if(r.files.put(s.path,s)!=null)throw new IOException("更新文件重复");
        }
        CatalogBundle.validateSet(r.files,r.total);
        return r;
    }
    private Release readRelease(String id) throws Exception {
        if(!id.matches("r[0-9]+-[a-f0-9]{32}"))throw new IOException("更新记录无效");
        File dir=new File(root,id);
        byte[] raw=readLimited(new FileInputStream(new File(dir,"_manifest.json")),MANIFEST_LIMIT);
        Release r=parse(new JSONObject(new String(raw,StandardCharsets.UTF_8)));
        if(r.minApp>APP_CODE || r.code<APP_CODE)throw new IOException("更新版本不兼容");
        r.id=id;r.directory=dir;
        CatalogBundle.verifyDirectory(dir,r.files,r.total);
        knownReleases.put(r.id,r);
        return r;
    }
    private void persist() throws Exception {
        JSONObject j=new JSONObject().put("active",active==null?"":active.id).put("previous",previousId).put("pending",pending);
        FileOutputStream out=null;
        try {out=stateFile.startWrite();out.write(j.toString().getBytes(StandardCharsets.UTF_8));stateFile.finishWrite(out);}
        catch(Exception e){if(out!=null)stateFile.failWrite(out);throw e;}
    }
    public void markHealthy(String token) {
        if(closed||!pending||!activeToken().equals(token))return;
        worker.execute(()->{
            if(closed||!pending||!activeToken().equals(token))return;
            try {pending=false;persist();publish("updated","在线更新成功，已启用新界面和资料",100);cleanup();}
            catch(Exception e){publish("error","更新状态保存未完成，下次启动将恢复原版本",0);}
        });
    }
    public void rollback(String token) {
        if(closed||!pending||!activeToken().equals(token))return;
        worker.execute(()->{
            if(closed||!pending||!activeToken().equals(token))return;
            try {
                try{active=readRelease(previousId);}catch(Exception e){active=null;}
                pending=false;previousId="";persist();
                publish("rolled_back","新界面未能正常打开，已恢复原版本",0);reload();
            }catch(Exception e){publish("error","请使用恢复内置资料",0);}
        });
    }
    public InputStream openToken(String token,String path) throws IOException {
        if(!CatalogBundle.validPath(path))throw new FileNotFoundException();
        Release r="bundled".equals(token)?null:knownReleases.get(token);
        if(r==null&&!"bundled".equals(token))throw new FileNotFoundException();
        if(r!=null) {
            CatalogBundle.Spec spec=r.files.get(path);
            if(spec==null)throw new FileNotFoundException();
            return new FileInputStream(new File(r.directory,path));
        }
        return context.getAssets().open(path);
    }
    private void cleanup() {
        File[] children=root.listFiles();
        if(children==null)return;
        String keep=active==null?"":active.id;
        for(File f:children) {
            String n=f.getName();
            if((n.startsWith("stage-")||n.startsWith("download-")||n.matches("r[0-9]+-[a-f0-9]{32}")) &&
                !n.equals(keep) && !n.equals(previousId)) CatalogBundle.deleteTree(f);
        }
    }
    private static HttpURLConnection connection(String url) throws Exception {
        if(!CatalogBundle.trustedUrl(url))throw new IOException("更新来源不可信");
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setInstanceFollowRedirects(false);c.setUseCaches(false);
        c.setConnectTimeout(15000);c.setReadTimeout(30000);
        c.setRequestProperty("Cache-Control","no-cache, no-store");
        c.setRequestProperty("Accept-Encoding","identity");
        if(c.getResponseCode()!=200){c.disconnect();throw new IOException("更新通道暂不可用，请稍后重试");}
        return c;
    }
    private byte[] downloadBytes(String url,int limit) throws Exception {
        cancelled();HttpURLConnection c=connection(url);activeConnection=c;
        try{cancelled();return readLimited(c.getInputStream(),limit);}finally{c.disconnect();activeConnection=null;}
    }
    private void downloadBundle(Release r,File file) throws Exception {
        cancelled();HttpURLConnection c=connection(r.url);activeConnection=c;
        try(InputStream in=c.getInputStream();OutputStream out=new BufferedOutputStream(new FileOutputStream(file))) {
            long length=c.getContentLengthLong();
            if(length>0 && length!=r.zipSize)throw new IOException("更新包大小不匹配");
            byte[] bytes=new byte[65536];int n,last=-1;long total=0;
            while((n=in.read(bytes))!=-1) {
                cancelled();
                total+=n;if(total>r.zipSize)throw new IOException("更新包大小超限");
                out.write(bytes,0,n);
                int p=(int)(total*80/r.zipSize);
                if(p!=last){last=p;publish("downloading","正在下载界面、图片和目录",p);}
            }
            if(total!=r.zipSize)throw new IOException("更新下载不完整，已保留原版本");
        }finally{c.disconnect();activeConnection=null;}
    }
    static byte[] readLimited(InputStream input,int limit) throws IOException {
        try(InputStream in=input;ByteArrayOutputStream out=new ByteArrayOutputStream()) {
            byte[] b=new byte[65536];int n;
            while((n=in.read(b))!=-1){if(out.size()+n>limit)throw new IOException("更新文件大小超限");out.write(b,0,n);}
            return out.toByteArray();
        }
    }
    private static void write(File f,byte[] bytes)throws IOException {
        try(FileOutputStream out=new FileOutputStream(f)){out.write(bytes);out.getFD().sync();}
    }
    public void close(){closed=true;HttpURLConnection c=activeConnection;if(c!=null)c.disconnect();}
}