package com.edwin.sofacatalog;

import android.app.*;
import android.os.*;
import android.content.Intent;
import android.net.Uri;
import android.webkit.*;
import android.widget.Toast;
import java.io.*;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    private static final String LEGACY_PAGE="file:///android_asset/index.html";
    private static final String PAGE="https://appassets.androidplatform.net/sofa-catalog/index.html";
    private static final String RESOURCE_BASE="https://appassets.androidplatform.net/sofa-catalog/";
    private WebView web;
    private CatalogUpdateStore updates;
    private final Handler main=new Handler(Looper.getMainLooper());
    private volatile boolean localPage=false,destroyed=false;
    private boolean migrating=false,started=false;
    private String pageToken="bundled";
    private android.content.SharedPreferences migration;
    private int loadId=0;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xff173b38);
        getWindow().setNavigationBarColor(0xff173b38);
        web=new WebView(this);setContentView(web);
        WebView.setWebContentsDebuggingEnabled(false);
        WebSettings settings=web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web,false);
        updates=new CatalogUpdateStore(this,new CatalogUpdateStore.Listener() {
            public void changed(String json){main.post(()->emit(json));}
            public void reload(){main.post(()->loadCatalog());}
        });
        migration=getSharedPreferences("catalog-migration",MODE_PRIVATE);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest req) {
                if(!req.isForMainFrame())return true;
                return route(req.getUrl().toString());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v,String url){return route(url);}
            @Override public void onPageStarted(WebView v,String url,android.graphics.Bitmap icon) {
                localPage=!migrating&&isLocal(url);
            }
            @Override public void onPageFinished(WebView v,String url) {
                if(migrating && LEGACY_PAGE.equals(url)) {readLegacyFavorites();return;}
                localPage=isLocal(url);
                if(!localPage)return;
                finishFavoriteMigration();
                emit(updates.status());
                final int id=loadId; final String token=pageToken;
                main.postDelayed(()->checkHealthy(id,token),700);
            }
            @Override public void onReceivedError(WebView v,WebResourceRequest req,WebResourceError e) {
                if(req.isForMainFrame()) {
                    if(migrating)beginCatalog();
                    else updates.rollback(pageToken);
                }
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest req) {
                return resource(req.getUrl().toString());
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v,String url){return resource(url);}
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onJsConfirm(WebView v,String url,String text,JsResult result){
                if(!localPage||!isLocal(url)){result.cancel();return true;}
                new AlertDialog.Builder(MainActivity.this).setTitle("沙发图鉴").setMessage(text)
                    .setPositiveButton("继续",(d,w)->result.confirm()).setNegativeButton("取消",(d,w)->result.cancel())
                    .setOnCancelListener(d->result.cancel()).show();return true;
            }
            @Override public boolean onJsAlert(WebView v,String url,String text,JsResult result){
                if(!localPage||!isLocal(url)){result.cancel();return true;}
                new AlertDialog.Builder(MainActivity.this).setTitle("沙发图鉴").setMessage(text)
                    .setPositiveButton("确定",(d,w)->result.confirm()).setOnCancelListener(d->result.cancel()).show();return true;
            }
        });
        if(migration.getBoolean("legacy-read-complete",false))beginCatalog();
        else {migrating=true;web.loadUrl(LEGACY_PAGE);}
    }
    private void beginCatalog(){
        if(started||destroyed)return;
        started=true;migrating=false;localPage=false;
        web.getSettings().setAllowFileAccess(false);
        web.addJavascriptInterface(new UpdateBridge(),"CatalogUpdater");
        loadCatalog();updates.start();
    }
    private void readLegacyFavorites(){
        web.evaluateJavascript("(function(){try{return JSON.stringify({ok:true,value:localStorage.getItem('sofa-favorites')});}catch(e){return JSON.stringify({ok:false});}})()",value->{
            try {
                Object decoded=new JSONTokener(value).nextValue();
                JSONObject answer=new JSONObject(String.valueOf(decoded));
                if(answer.optBoolean("ok")){
                    String raw=answer.isNull("value")?"[]":answer.getString("value");
                    if(raw.length()>512000)throw new Exception("favorite size");
                    JSONArray list=new JSONArray(raw);
                    if(list.length()>6000)throw new Exception("favorite count");
                    for(int i=0;i<list.length();i++)if(!(list.get(i) instanceof String))throw new Exception("favorite type");
                    migration.edit().putString("legacy-favorites-backup",raw).putBoolean("legacy-read-complete",true).commit();
                }
            }catch(Exception ignored){}
            beginCatalog();
        });
    }
    private String favoriteImport(){
        if(!migration.getBoolean("legacy-read-complete",false)||migration.getBoolean("https-import-complete",false))return "";
        String raw=migration.getString("legacy-favorites-backup","[]");
        String literal=JSONObject.quote(raw).replace("<","\\u003c").replace("\u2028","\\u2028").replace("\u2029","\\u2029");
        return "<script>try{var __saved=localStorage.getItem('sofa-favorites');if(__saved===null){"
            +"localStorage.setItem('sofa-favorites',"+literal+");__saved=localStorage.getItem('sofa-favorites');"
            +"window.__catalogFavoriteMigration=__saved==="+literal+"?'ok':'retry';"
            +"}else{window.__catalogFavoriteMigration='ok';}}catch(e){}</script>";
    }
    private void finishFavoriteMigration(){
        if(migration.getBoolean("https-import-complete",false))return;
        web.evaluateJavascript("window.__catalogFavoriteMigration==='ok'",value->{
            if("true".equals(value))migration.edit().putBoolean("https-import-complete",true).commit();
        });
    }
    private boolean isLocal(String url) {
        return url!=null && (url.equals(PAGE)||url.startsWith(PAGE+"#")||url.startsWith(PAGE+"?"));
    }
    private boolean route(String url) {
        if(isLocal(url))return false;
        Uri u=Uri.parse(url);
        if("https".equalsIgnoreCase(u.getScheme()) && !"appassets.androidplatform.net".equalsIgnoreCase(u.getHost()))
            openExternal(url);
        return true;
    }
    private void loadCatalog() {
        if(destroyed)return;
        int id=++loadId;
        try {
            CatalogUpdateStore.Page snapshot=updates.page();
            String html=snapshot.html;
            pageToken=snapshot.token;
            String policy="default-src 'none'; script-src https://appassets.androidplatform.net 'unsafe-inline'; "
                +"style-src https://appassets.androidplatform.net 'unsafe-inline'; img-src https: data:; "
                +"font-src https://appassets.androidplatform.net; connect-src 'none'; frame-src 'none'; "
                +"child-src 'none'; object-src 'none'; form-action 'none'; "
                +"base-uri https://appassets.androidplatform.net";
            String head="<meta http-equiv=\"Content-Security-Policy\" content=\""+policy+"\">"
                +"<base href=\""+RESOURCE_BASE+pageToken+"/\">"
                +"<meta name=\"catalog-native-load\" content=\""+id+"\">"+favoriteImport();
            int pos=html.toLowerCase(Locale.ROOT).indexOf("<head>");
            if(pos<0)throw new IOException("missing head");
            html=html.substring(0,pos+6)+head+html.substring(pos+6);
            localPage=true;
            web.loadDataWithBaseURL(PAGE,html,"text/html","UTF-8",PAGE);
        }catch(Exception e) {
            updates.rollback(pageToken);
            new AlertDialog.Builder(this).setTitle("资料未能打开")
                .setMessage("可以恢复内置资料，收藏会保留。")
                .setPositiveButton("恢复内置资料",(d,w)->updates.restoreBundled())
                .setNegativeButton("关闭",null).show();
        }
    }
    private void checkHealthy(int id,String token) {
        if(destroyed||!localPage||id!=loadId)return;
        String js="(function(){var marker=document.querySelector('meta[name=\"catalog-native-load\"]');"
            +"return !!(marker&&marker.content==='"+id+"'&&document.getElementById('grid')"
            +"&&typeof DATA!=='undefined'&&DATA.rows&&DATA.rows.length"
            +"&&document.getElementById('grid').children.length);})()";
        web.evaluateJavascript(js,value->{
            if(id!=loadId||destroyed)return;
            if("true".equals(value))updates.markHealthy(token);
            else main.postDelayed(()->{if(id==loadId)updates.rollback(token);},5000);
        });
    }
    private WebResourceResponse resource(String url) {
        if(migrating && LEGACY_PAGE.equals(url))return null;
        if(url.startsWith(RESOURCE_BASE)) {
            try {
                Uri u=Uri.parse(url);
                String suffix=u.getPath().substring("/sofa-catalog/".length());
                int slash=suffix.indexOf('/');
                if(slash<1)return denied();
                String token=suffix.substring(0,slash),path=suffix.substring(slash+1);
                if(u.getQuery()!=null||u.getFragment()!=null) {
                    // Version cache-busters never change the file selected.
                }
                if(!CatalogBundle.validPath(path))return denied();
                InputStream in=updates.openToken(token,path);
                Map<String,String> headers=new HashMap<>();
                headers.put("Cache-Control","no-store");
                headers.put("Access-Control-Allow-Origin","*");
                headers.put("X-Content-Type-Options","nosniff");
                return new WebResourceResponse(mime(path),"UTF-8",200,"OK",headers,in);
            }catch(Exception e){return denied();}
        }
        // CSP permits remote images only. All script/frame/network capabilities remain local.
        Uri u=Uri.parse(url);
        if("file".equalsIgnoreCase(u.getScheme())||"content".equalsIgnoreCase(u.getScheme())||
           "http".equalsIgnoreCase(u.getScheme())||"appassets.androidplatform.net".equalsIgnoreCase(u.getHost()))
            return denied();
        return null;
    }
    private static WebResourceResponse denied() {
        return new WebResourceResponse("text/plain","UTF-8",403,"Blocked",Collections.singletonMap("Cache-Control","no-store"),
            new ByteArrayInputStream(new byte[0]));
    }
    private static String mime(String path) {
        String p=path.toLowerCase(Locale.ROOT);
        if(p.endsWith(".html"))return "text/html";
        if(p.endsWith(".js"))return "text/javascript";
        if(p.endsWith(".css"))return "text/css";
        if(p.endsWith(".json"))return "application/json";
        if(p.endsWith(".png"))return "image/png";
        if(p.endsWith(".webp"))return "image/webp";
        if(p.endsWith(".svg"))return "image/svg+xml";
        if(p.endsWith(".gif"))return "image/gif";
        if(p.endsWith(".woff2"))return "font/woff2";
        if(p.endsWith(".woff"))return "font/woff";
        return "image/jpeg";
    }
    private void emit(String json) {
        if(destroyed||!localPage||web==null)return;
        web.evaluateJavascript("window.onCatalogUpdate&&window.onCatalogUpdate("+json+");",null);
    }
    private void openExternal(String url) {
        try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}
        catch(Exception e){Toast.makeText(this,"请联网并安装浏览器后查看",Toast.LENGTH_LONG).show();}
    }
    private final class UpdateBridge {
        @JavascriptInterface public String status(){return localPage&&!destroyed?updates.status():"{}";}
        @JavascriptInterface public String check(){return localPage&&!destroyed?updates.check():"{}";}
        @JavascriptInterface public String repair(){return localPage&&!destroyed?updates.repair():"{}";}
        @JavascriptInterface public String restoreBundled(){return localPage&&!destroyed?updates.restoreBundled():"{}";}
        @JavascriptInterface public String openInstaller(){
            if(!localPage||destroyed)return "{}";
            main.post(()->new AlertDialog.Builder(MainActivity.this).setTitle("下载安装包")
                .setMessage("将打开本应用的下载页。请覆盖安装，不要先卸载；安装由 Android 系统确认。")
                .setPositiveButton("打开下载页",(d,w)->openExternal(CatalogUpdateStore.INSTALLER))
                .setNegativeButton("取消",null).show());
            return updates.status();
        }
    }
    @Override public void onBackPressed() {
        web.evaluateJavascript("window.appBack ? window.appBack() : false",value->{if(!"true".equals(value))finish();});
    }
    @Override public void onDestroy() {
        destroyed=true;localPage=false;main.removeCallbacksAndMessages(null);
        if(web!=null){web.removeJavascriptInterface("CatalogUpdater");web.destroy();}
        if(updates!=null)updates.close();
        super.onDestroy();
    }
}