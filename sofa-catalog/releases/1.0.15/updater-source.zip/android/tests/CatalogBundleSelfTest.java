package com.edwin.sofacatalog;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;
import java.util.zip.*;

public class CatalogBundleSelfTest {
    static File root; static int passed=0;
    interface Check { void run() throws Exception; }
    static void ok(String name,Check c)throws Exception {c.run();passed++;System.out.println("PASS "+name);}
    static void reject(String name,Check c)throws Exception {
        try {c.run();throw new AssertionError("unexpected acceptance: "+name);}
        catch(IOException expected){passed++;System.out.println("PASS "+name);}
    }
    static Map<String,byte[]> contents(){
        Map<String,byte[]> x=new LinkedHashMap<>();
        x.put("index.html","<html><head></head><body>catalog</body></html>".getBytes(StandardCharsets.UTF_8));
        x.put("data.js","const DATA={rows:[{name:'sofa'}]};".getBytes(StandardCharsets.UTF_8));
        return x;
    }
    static File zip(String name,Map<String,byte[]> c)throws Exception {
        File f=new File(root,name+".zip");
        try(ZipOutputStream z=new ZipOutputStream(new FileOutputStream(f))){
            for(Map.Entry<String,byte[]> e:c.entrySet()){z.putNextEntry(new ZipEntry(e.getKey()));z.write(e.getValue());z.closeEntry();}
        }return f;
    }
    static Map<String,CatalogBundle.Spec> specs(Map<String,byte[]> c)throws Exception{
        Map<String,CatalogBundle.Spec> map=new LinkedHashMap<>();
        for(Map.Entry<String,byte[]> e:c.entrySet()){
            File f=new File(root,"hash-input");Files.write(f.toPath(),e.getValue());
            map.put(e.getKey(),new CatalogBundle.Spec(e.getKey(),CatalogBundle.hash(f),e.getValue().length));
        }return map;
    }
    static long total(Map<String,byte[]> c){long n=0;for(byte[] b:c.values())n+=b.length;return n;}
    static void ensure(boolean x){if(!x)throw new AssertionError();}
    public static void main(String[] args)throws Exception {
        root=Files.createTempDirectory("sofa-native-validator-").toFile();
        try{
            Map<String,byte[]> c=contents(); Map<String,CatalogBundle.Spec> s=specs(c);long n=total(c);
            ok("valid-complete-snapshot",()->{
                File out=new File(root,"good");CatalogBundle.extract(zip("good",c),out,s,n);
                CatalogBundle.verifyDirectory(out,s,n);
            });
            reject("reject-tampered-file",()->{
                Map<String,byte[]> bad=contents();bad.put("data.js","x".getBytes(StandardCharsets.UTF_8));
                CatalogBundle.extract(zip("tampered",bad),new File(root,"bad1"),s,n);
            });
            reject("reject-missing-file",()->{
                Map<String,byte[]> bad=contents();bad.remove("data.js");
                CatalogBundle.extract(zip("missing",bad),new File(root,"bad2"),s,n);
            });
            reject("reject-undeclared-file",()->{
                Map<String,byte[]> bad=contents();bad.put("extra.js",new byte[]{1});
                CatalogBundle.extract(zip("extra",bad),new File(root,"bad3"),s,n);
            });
            reject("reject-zip-path-traversal",()->{
                Map<String,byte[]> bad=contents();bad.put("../outside.js",new byte[]{1});
                CatalogBundle.extract(zip("traversal",bad),new File(root,"bad4"),s,n);
            });
            reject("reject-expanded-size-mismatch",()->CatalogBundle.validateSet(s,n+1));
            reject("reject-case-collision",()->{
                Map<String,CatalogBundle.Spec> bad=new LinkedHashMap<>(s);
                CatalogBundle.Spec first=s.get("data.js");
                bad.put("DATA.js",new CatalogBundle.Spec("DATA.js",first.hash,first.size));
                CatalogBundle.validateSet(bad,n+first.size);
            });
            ok("reject-untrusted-url-host-path-query",()->{
                String[] bad={"http://teopoh71.github.io/hp-sofa-updates/sofa-catalog/a.zip",
                    "https://evil.example/hp-sofa-updates/sofa-catalog/a.zip",
                    "https://teopoh71.github.io/hp-sofa-updates/sofa-catalog/../handphone/a.zip",
                    "https://teopoh71.github.io/hp-sofa-updates/sofa-catalog/%2e%2e/a.zip",
                    "https://teopoh71.github.io/hp-sofa-updates/sofa-catalog/a.zip?url=evil",
                    "https://teopoh71.github.io/hp-sofa-updates/sofa-catalog@evil.example/a.zip",
                    "https://user@teopoh71.github.io/hp-sofa-updates/sofa-catalog/a.zip"};
                for(String x:bad)ensure(!CatalogBundle.trustedUrl(x));
                ensure(CatalogBundle.trustedUrl(CatalogBundle.BASE+"releases/1.0.15/content.zip"));
            });
            ok("reject-unsafe-file-paths",()->{
                String[] bad={"/index.html","../index.html","images/../a.jpg","a\\b.js","file:a.js","./data.js","a//b.js","a.exe","a%2f.js"};
                for(String x:bad)ensure(!CatalogBundle.validPath(x));
                ensure(CatalogBundle.validPath("images/sofa-cutout-1.png"));
            });
            reject("detect-post-install-corruption",()->{
                File good=new File(root,"good");Files.write(new File(good,"data.js").toPath(),new byte[]{1});
                CatalogBundle.verifyDirectory(good,s,n);
            });
            reject("reject-directory-payload",()->{
                Map<String,byte[]> bad=contents();bad.put("images/",new byte[]{1,2,3,4});
                CatalogBundle.extract(zip("directory-payload",bad),new File(root,"bad-dir"),s,n);
            });
            ok("reject-reserved-metadata-path",()->ensure(!CatalogBundle.validPath("_manifest.json")));
            System.out.println("RESULT "+passed+"/12 checks passed");
        }finally{CatalogBundle.deleteTree(root);}
    }
}